﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_consultorio
{
    public partial class FormEnfermedades : Form
    {
        public FormEnfermedades()
        {
            InitializeComponent();
        }

        private void FormEnfermedades_Load(object sender, EventArgs e)
        {

        }
    }
}
